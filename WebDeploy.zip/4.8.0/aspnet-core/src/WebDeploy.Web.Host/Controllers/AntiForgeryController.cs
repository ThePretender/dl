using Microsoft.AspNetCore.Antiforgery;
using WebDeploy.Controllers;

namespace WebDeploy.Web.Host.Controllers
{
    public class AntiForgeryController : WebDeployControllerBase
    {
        private readonly IAntiforgery _antiforgery;

        public AntiForgeryController(IAntiforgery antiforgery)
        {
            _antiforgery = antiforgery;
        }

        public void GetToken()
        {
            _antiforgery.SetCookieTokenAndHeader(HttpContext);
        }
    }
}
