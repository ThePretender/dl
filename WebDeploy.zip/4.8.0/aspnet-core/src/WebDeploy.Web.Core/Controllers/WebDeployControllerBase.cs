using Abp.AspNetCore.Mvc.Controllers;
using Abp.IdentityFramework;
using Microsoft.AspNetCore.Identity;

namespace WebDeploy.Controllers
{
    public abstract class WebDeployControllerBase: AbpController
    {
        protected WebDeployControllerBase()
        {
            LocalizationSourceName = WebDeployConsts.LocalizationSourceName;
        }

        protected void CheckErrors(IdentityResult identityResult)
        {
            identityResult.CheckErrors(LocalizationManager);
        }
    }
}
