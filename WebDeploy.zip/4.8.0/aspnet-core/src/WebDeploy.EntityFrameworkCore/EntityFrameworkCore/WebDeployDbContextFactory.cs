﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using WebDeploy.Configuration;
using WebDeploy.Web;

namespace WebDeploy.EntityFrameworkCore
{
    /* This class is needed to run "dotnet ef ..." commands from command line on development. Not used anywhere else */
    public class WebDeployDbContextFactory : IDesignTimeDbContextFactory<WebDeployDbContext>
    {
        public WebDeployDbContext CreateDbContext(string[] args)
        {
            var builder = new DbContextOptionsBuilder<WebDeployDbContext>();
            var configuration = AppConfigurations.Get(WebContentDirectoryFinder.CalculateContentRootFolder());

            WebDeployDbContextConfigurer.Configure(builder, configuration.GetConnectionString(WebDeployConsts.ConnectionStringName));

            return new WebDeployDbContext(builder.Options);
        }
    }
}
