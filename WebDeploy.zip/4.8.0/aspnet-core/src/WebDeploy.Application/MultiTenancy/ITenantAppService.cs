﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using WebDeploy.MultiTenancy.Dto;

namespace WebDeploy.MultiTenancy
{
    public interface ITenantAppService : IAsyncCrudAppService<TenantDto, int, PagedTenantResultRequestDto, CreateTenantDto, TenantDto>
    {
    }
}

