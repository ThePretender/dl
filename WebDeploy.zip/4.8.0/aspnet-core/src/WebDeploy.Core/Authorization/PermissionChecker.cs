﻿using Abp.Authorization;
using WebDeploy.Authorization.Roles;
using WebDeploy.Authorization.Users;

namespace WebDeploy.Authorization
{
    public class PermissionChecker : PermissionChecker<Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {
        }
    }
}
