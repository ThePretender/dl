﻿namespace WebDeploy
{
    public class WebDeployConsts
    {
        public const string LocalizationSourceName = "WebDeploy";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
