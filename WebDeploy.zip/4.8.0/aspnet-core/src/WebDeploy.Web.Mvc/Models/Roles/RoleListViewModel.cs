﻿using System.Collections.Generic;
using WebDeploy.Roles.Dto;

namespace WebDeploy.Web.Models.Roles
{
    public class RoleListViewModel
    {
        public IReadOnlyList<RoleListDto> Roles { get; set; }

        public IReadOnlyList<PermissionDto> Permissions { get; set; }
    }
}
