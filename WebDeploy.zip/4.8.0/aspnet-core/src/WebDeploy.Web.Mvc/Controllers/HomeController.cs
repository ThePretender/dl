﻿using Microsoft.AspNetCore.Mvc;
using Abp.AspNetCore.Mvc.Authorization;
using WebDeploy.Controllers;

namespace WebDeploy.Web.Controllers
{
    [AbpMvcAuthorize]
    public class HomeController : WebDeployControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}
